"""
Implementation of the NSGAII MOEA
Author: Luis Andrés Eguiarte-Morett (Github: @leguiart)
License: MIT. 
"""
from hklearn_genetic.Problems.IProblem import IProblem
import numpy as np
import random
import math
import copy

class NSGAII:
    def __init__(self, max_iter : int = 5000, tournament_type : int = 0, tournament_size = 2):
        self.max_iter = max_iter
        self.k_tournament = tournament_size
        self.tournament_type = tournament_type

    def evolve(self, problem : IProblem, n_individuals : int):
        #Initialize population
        its = 0
        parent_pop = problem.populate(n_individuals)
        parent_pop = problem.evaluate(parent_pop)
        self._non_dominated_sorting(parent_pop)
        child_pop = self._select(problem, parent_pop)
        child_pop = problem.generate(child_pop)
        population = parent_pop + child_pop
        while its < self.max_iter: 
            fronts = self._non_dominated_sorting(population)
            parent_pop = []
            for front in fronts:

                if len(front) + len(parent_pop) > n_individuals:
                    self._get_crowding_distance(front)
                    front.sort(key = lambda x : x.crowding_distance, reverse= True)
                    parent_pop += front[0: n_individuals - len(parent_pop)]
                    break
                elif len(front) + len(parent_pop) == n_individuals:
                    parent_pop += front
                    break
                else:
                    parent_pop += front
            child_pop = self._select(problem, parent_pop)
            child_pop = problem.generate(child_pop)
            population = parent_pop + child_pop
            #print(len(population))
            its+=1

        return fronts[0]
        # if len(solutions) == 0:
        #     return (self.pop[-1].phenotype, -self.pop[-1].fitness_metric)
        # else:
        #     return solutions

    def _non_dominated_sorting(self, population : list):
        fronts = [[]]
        for p in population:
            p.dominated = []
            p.domination_counter = 0

            for q in population:
                if q is not p:
                    if p.dominates(q):
                        p.dominated.append(q)
                    elif q.dominates(p):
                        p.domination_counter += 1
            if p.domination_counter == 0:
                fronts[0] += [p]
                p.rank = 1
        #Initialize front counter
        i = 0
        while len(fronts[i]) != 0:
            next_front_members = []
            for p in fronts[i]:
                for q in p.dominated:
                    q.domination_counter -= 1
                    if q.domination_counter == 0:
                        q.rank = i + 1
                        next_front_members += [q]
            fronts.append(next_front_members)
            i+=1
        fronts.pop()
        return fronts

    def _get_crowding_distance(self, front):
        M = len(front[0].fitness_metric)
        min_max = []
        for i in range(M):
            max_val = float('-inf')
            min_val = float('inf')
            for p in front:
                if max_val < p.fitness_metric[i]:
                    max_val = p.fitness_metric[i]
                if min_val > p.fitness_metric[i]:
                    min_val = p.fitness_metric[i]
            min_max += [(min_val, max_val)]

        for p in front:
            p.crowding_distance = 0
        for i in range(M):
            front.sort(key = lambda x : x.fitness_metric[i])
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            for j in range(1, len(front) - 1):
                front[j].crowding_distance += (front[j + 1].fitness_metric[i] - front[j - 1].fitness_metric[i])/(min_max[i][1] - min_max[i][0]) 
        return front


    def _get_roulette_probs(self, n_individuals : int):
        return np.random.uniform(size = (1, n_individuals))

    def _select(self, problem : IProblem, population : list):
        """Evaluates the population of solutions based on the problem and 
        applies the chosen selection operator over the evaluated proposed solutions
        Parameters
        ----------
        problem : IProblem
            problem object wich implements the IProblem interface
        population : list
            list of objects, each representing a proposed solution
        """
        population = problem.evaluate(population)
        # population.sort(key = lambda x : x.fitness_metric)
        #fitness_metrics = [individual.fitness_metric for individual in population]
        child_population = []
        t = 0
        #with replacement
        if self.tournament_type == 1:
            
            while t < len(population):
                tournament_contestants = np.random.permutation(len(population))[0:self.k_tournament]
                greatest_score_so_far = float('-inf')
                tournament_winner = None
                for contestant in tournament_contestants:
                    if population[contestant].rank > greatest_score_so_far:
                        greatest_score_so_far = population[contestant].rank
                        #population[t] = copy.deepcopy(population[contestant])
                        tournament_winner = copy.deepcopy(population[contestant])
                child_population += [tournament_winner]
                t+=1
        #without replacement
        elif self.tournament_type == 0:
            while t < len(population):
                permutation = np.random.permutation(len(population))
                i = 0
                tournament_winner = None
                while i < len(permutation) and t < len(population):
                    greatest_score_so_far = float('-inf')
                    for j in range(i,min(i + self.k_tournament, len(population))):
                        if population[permutation[j]].rank > greatest_score_so_far:
                            greatest_score_so_far = population[j].rank
                            tournament_winner = copy.deepcopy(population[permutation[j]])
                            #population[t] = 
                    child_population += [tournament_winner]
                    t+=1
                    i+=self.k_tournament
        return child_population
