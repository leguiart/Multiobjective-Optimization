"""
Implementation of the NSGAIII MOEA
Author: Luis Andrés Eguiarte-Morett (Github: @leguiart)
License: MIT. 
"""
from numpy.core.fromnumeric import shape
from hklearn_genetic.Problems.IProblem import IProblem
from deap import tools
import numpy as np
import random
import math
import copy

class NSGAIII:
    def __init__(self, max_iter : int = 5000):
        self.max_iter = max_iter

    def evolve(self, problem : IProblem, n_individuals : int):
        #Initialize population
        its = 0
        structured_ref_points = tools.uniform_reference_points(nobj=3, p=12)
        structured_ref_points = list(structured_ref_points)       
        ideal_point = None
        worst_point = None
        extreme_points = []
        epsilon_nadir = 2.
        #child_pop = self._select(problem, parent_pop)
        parent_pop = problem.populate(n_individuals)
        child_pop = problem.generate(parent_pop)
        population = parent_pop + child_pop
        population = problem.evaluate(population)
        while its < self.max_iter:          
            fronts = self._non_dominated_sorting(population)
            parent_pop = []
            last_front = []
            for front in fronts:
                if len(front) + len(parent_pop) > n_individuals:
                    last_front = front
                    #parent_pop += front
                    break
                elif len(front) + len(parent_pop) == n_individuals:
                    parent_pop += front
                    break
                else:
                    parent_pop += front
            if len(last_front) != 0:
                k = n_individuals - len(parent_pop)
                s_t = parent_pop + last_front
                #Normalize objectives
                ideal_point, worst_point, extreme_points = self._normalize(problem.evaluator, s_t, ideal_point, worst_point, fronts[0], extreme_points, epsilon_nadir)
                #Associate each member of parent_pop in the normalized space with a reference point
                self._associate(s_t, ideal_point, structured_ref_points)
                #Compute niche count for each reference point
                niche_counts = [0 for i in range(len(structured_ref_points))]
                for p in parent_pop:
                    niche_counts[p.reference_line[1]]+=1              
                self._niching(k, niche_counts, structured_ref_points, last_front, parent_pop)
            # child_pop = self._select(problem, parent_pop)
            child_pop = problem.generate(parent_pop)
            population = parent_pop + child_pop
            parent_pop = problem.evaluate(population)
            M = len(population[0].fitness_metric)
            problem.evaluator.ideal_point = np.zeros(shape = M)
            problem.evaluator.intercepts = np.ones(shape = M)
            its+=1

        return problem.evaluate(fronts[0])

    def _calculate_ideal(self, previous_ideal, solutions):
        M = len(solutions[0].fitness_metric)
        #Calculate the ideal point
        if previous_ideal is None:
            previous_ideal = np.zeros(shape=M)
            for i in range(M):
                min_val = float('inf')
                for p in solutions:
                    if min_val > p.fitness_metric[i]:
                        min_val = p.fitness_metric[i]
                previous_ideal[i] = min_val
        else:
            for i in range(M):
                for p in solutions:
                    if previous_ideal[i] > p.fitness_metric[i]:
                        previous_ideal[i] = p.fitness_metric[i]
                    
        return previous_ideal

    def _calculate_worst(self, previous_worst, solutions):
        M = len(solutions[0].fitness_metric)
        #Calculate the ideal point
        if previous_worst is None:
            previous_worst = np.zeros(shape=M)
            for i in range(M):
                max_val = float('-inf')
                for p in solutions:
                    if max_val < p.fitness_metric[i]:
                        max_val = p.fitness_metric[i]
                previous_worst[i] = max_val
        else:
            for i in range(M):
                for p in solutions:
                    if previous_worst[i] < p.fitness_metric[i]:
                        previous_worst[i] = p.fitness_metric[i]
        return previous_worst

    def _normalize(self, evaluator, population, previous_ideal, previous_worst ,first_front, extreme_points, epsilon_nad):
        M = len(population[0].fitness_metric)

        #Translating objectives
        #Calculate the ideal point
        previous_ideal = self._calculate_ideal(previous_ideal, population)
        #Calculate the worst point
        previous_worst = self._calculate_worst(previous_worst, first_front)
        evaluator.ideal_point = previous_ideal
        for p in population:
            p.fitness_metric -= previous_ideal

        #Computing extreme points
        epsilon = 10e-6
        w = np.array([epsilon for i in range(M)])
        initial_extreme_points = len(extreme_points) == 0
        R = [p.fitness_metric for p in population]
        A = R + extreme_points
        for i in range(M):
            if i - 1 > -1:
                w[i - 1] = epsilon
            w[i] = 1
            candidate_extreme_point = None
            min_val = float('inf')
            for p in R:
                asf = self._ASF(p, w, previous_ideal)
                if min_val > asf:
                    min_val = asf
                    candidate_extreme_point = p
            if initial_extreme_points:
                extreme_points += [candidate_extreme_point]
            else:
                extreme_points[i] = [candidate_extreme_point]
        vect_extreme_points = np.array(extreme_points)
        #Obtaining intercepts
        #We have to handle certain special cases      
        b = False
        try:
            #Non-invertible matrix
            if np.linalg.det(vect_extreme_points) == 0:
                b = True
            else:
                intercepts = np.linalg.inv(vect_extreme_points)@np.ones(shape = M)
                #Negative intercepts
                if len(intercepts[intercepts < 0]) > 0:
                    b = True
                else:
                    intercepts /= intercepts[-1]
                    intercepts = 1./intercepts
                    evaluator.nadir_point = intercepts + previous_ideal
        except:
            pass
        if b == True:
            evaluator.nadir_point = previous_worst
        for i in range(M):
            max_val = float('-inf')
            for p in population:
                if max_val < p.fitness_metric[i]:
                    max_val = p.fitness_metric[i]
            if evaluator.nadir_point[i] - evaluator.ideal[i] < epsilon_nad:
                evaluator.nadir_point[i] = max_val
        for p in population:
            p.fitness_metric/=(evaluator.nadir_point - evaluator.ideal_point)
        return previous_ideal, previous_worst, extreme_points
            

    def _ASF(self, f, w, ideal):
        return max([(f[i] - ideal[i])/w[i] for i in range(len(f))])
            
        
    def _associate(self, population, ideal_point, ref_points):
        reference_lines = []
        for z in ref_points:
            reference_lines += [ideal_point - z]
        for s in population:
            min_val = float('inf')
            w_min = None
            line_index = 0
            for i, w in enumerate(reference_lines):
                d = self._perpendicular_dist(s.fitness_metric, w, ideal_point - w)
                if min_val > d:
                    min_val = d
                    w_min = w
                    line_index = i
            try:
                s.reference_line = (ideal_point - w_min, line_index)
                s.distance = (min_val, line_index)
            except:
                pass
                
    
    def _perpendicular_dist(self, s, w, z):
        zs = s - z
        t = np.dot(zs, w)/np.dot(w, w)
        d = np.linalg.norm(zs - t * w, 2)
        return d

    def _niching(self, K, niche_counts, ref_points, last_front, parent_pop):
        k = 1
        ref_points_copy = ref_points.copy()
        while k <= K:
            #Get the niches with minimum associated points
            min_val = min(niche_counts)
            j_min = []
            for i, count in enumerate(niche_counts):
                if count == min_val:
                    j_min += [i]
            #Choose a niche from the ones with less associated points at random
            j = random.choice(j_min)
            #Get the elements in the last front associated with the niche j
            I_j = []
            #Los elementos de la lista last_front se deberían de haber actualizado porque 
            #se actualizaron sus referencias en la lista s_t, revisar que esto si suceda
            for s in last_front:
                if (s.reference_line[0] == ref_points_copy[j]).all():
                    I_j += [s]
            
            #If there are elements in the front associated with the niche j
            if len(I_j) != 0:
                s_to_add = None
                #If there are no elements from the previous generation parent population associated with niche j, but there are elements in the last front associated with niche j
                if niche_counts[j] == 0:
                    #get the element in the last front which is associated to the reference line from the niche j such that it has a minimal distance to the reference line
                    min_val = float('inf')
                    s_min = None
                    for s in I_j:
                        if min_val > s.distance[0]:
                            min_val = s.distance[0]
                            s_min = s
                    #We will add this element to the parent population of the next generation
                    s_to_add = s_min
                #If there are no elements from the previous generation parent population associated with niche j and there are elements in the last front associated with niche j 
                else:
                    #Just choose one element at random
                    s_to_add = random.choice(I_j)
                parent_pop += [s_to_add]
                niche_counts[j] += 1
                index = 0
                for i in range(len(last_front)):
                    if last_front[i] == s_to_add:
                        index = i
                        break
                last_front.pop(index)
                k += 1
            #If there are no elements in the front associated with the niche j
            else:
                #Stop considering that niche in for this generation
                index = 0
                for i in range(len(ref_points_copy)):
                    if (ref_points_copy[i] == ref_points_copy[j]).all():
                        index = i
                        break
                #Revisar bien esto, además solo remover el ref_point dentro de éste método y no para toda la optimización
                niche_counts.pop(index)
                ref_points_copy.pop(index)


    def _non_dominated_sorting(self, population : list):
        fronts = [[]]
        for i in range(len(population)):
            population[i].dominated = []
            population[i].domination_counter = 0

            for j in range(len(population)):
                if i != j:
                    if population[i].dominates(population[j]):
                        population[i].dominated.append(population[j])
                    elif population[j].dominates(population[i]):
                        population[i].domination_counter += 1
            if population[i].domination_counter == 0:
                fronts[0] += [population[i]]
                population[i].rank = 1
        #Initialize front counter
        i = 0
        while len(fronts[i]) != 0:
            next_front_members = []
            for p in fronts[i]:
                for q in p.dominated:
                    q.domination_counter -= 1
                    if q.domination_counter == 0:
                        q.rank = i + 1
                        next_front_members += [q]
            fronts.append(next_front_members)
            i+=1
        not_in_any_front = []
        for i in range(len(population)):
            in_front = False
            for front in fronts:
                if population[i] in front:
                    in_front = True
                    break
            if not in_front:
                not_in_any_front += [population[i]]
                
        fronts.pop()
        return fronts

