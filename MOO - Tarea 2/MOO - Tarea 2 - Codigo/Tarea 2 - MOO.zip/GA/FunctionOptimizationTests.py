from hklearn_genetic.utils import ProblemUtils
from hklearn_genetic.Evaluators.FunctionEvaluators import DTLZ1, DTLZ2
from hklearn_genetic.Problems import RealGAProblem, BaseGAProblem
from hklearn_genetic.NSGAIII import NSGAIII
from hklearn_genetic.NSGAII import NSGAII
import json
import os
import os.path

ANALITYCS = True
RUNS = 5

def save_json(path, analytics):
    with open(path + ".json", 'a') as fp:           
        fp.write('\n')
        json.dump(analytics, fp)

d = {"evaluations" : [], "phenotypes":[]}
analytics = {"DTLZ1-NSGA2" : {"evaluations" : [], "phenotypes":[]}, "DTLZ1-NSGA3" : {"evaluations" : [], "phenotypes":[]}, "DTLZ2-NSGA2" : {"evaluations" : [], "phenotypes":[]}, "DTLZ2-NSGA3" : {"evaluations" : [], "phenotypes":[]} }

def get_problems():
    #Defining evaluators
    dtlz1 = DTLZ1()
    dtlz2 = DTLZ2()

    #Defining problems
    #Real SBX crossover and polynomial mutation
    dtlz1_real_sbx = RealGAProblem._BaseRealGAProblem(dtlz1, -0.001, (0, 1), pc = .9, pm = 1/12, n_dim=12)
    dtlz2_real_sbx = RealGAProblem._BaseRealGAProblem(dtlz2, -0.001, (0, 1), pc = .9, pm = 1/12, n_dim=12)
    return dtlz1_real_sbx, dtlz2_real_sbx

#Defining the evolutionary algorithm
nsga2 = NSGAII(tournament_type = 1,max_iter=400)
nsga3 = NSGAIII(max_iter=400)

run  = 1
while run < RUNS:
    
    #DTLZ1 NSGA-II
    nsga2.max_iter = 1000
    print(f"starting NSGA-II DTLZ1 Optimization {run + 1}")
    dtlz1_real_sbx, dtlz2_real_sbx = get_problems()
    final_front = nsga2.evolve(dtlz1_real_sbx, 100)
    fitness = [list(p.fitness_metric) for p in final_front]
    phenotypes = [list(p.phenotype) for p in final_front]
    analytics["DTLZ1-NSGA2"]["evaluations"] = fitness
    analytics["DTLZ1-NSGA2"]["phenotypes"] = phenotypes
    
    #DTLZ1 NSGA-III
    nsga3.max_iter = 1000
    print(f"starting NSGA-III DTLZ1 Optimization {run + 1}")
    dtlz1_real_sbx, dtlz2_real_sbx = get_problems()
    final_front = nsga3.evolve(dtlz1_real_sbx, 92)
    dtlz1_real_sbx, _ = get_problems()
    final_front = dtlz1_real_sbx.evaluate(final_front)
    fitness = [list(p.fitness_metric) for p in final_front]
    phenotypes = [list(p.phenotype) for p in final_front]
    analytics["DTLZ1-NSGA3"]["evaluations"] = fitness
    analytics["DTLZ1-NSGA3"]["phenotypes"] = phenotypes

    #DTLZ2 NSGA-II
    nsga2.max_iter = 250
    print(f"starting NSGA-II DTLZ2 Optimization {run + 1}")
    dtlz1_real_sbx, dtlz2_real_sbx = get_problems()
    final_front = nsga2.evolve(dtlz2_real_sbx, 100)
    fitness = [list(p.fitness_metric) for p in final_front]
    phenotypes = [list(p.phenotype) for p in final_front]
    analytics["DTLZ2-NSGA2"]["evaluations"] = fitness
    analytics["DTLZ2-NSGA2"]["phenotypes"] = phenotypes

    #DTLZ2 NSGA-III
    nsga3.max_iter = 250
    print(f"starting NSGA-III DTLZ2 Optimization {run + 1}")
    dtlz1_real_sbx, dtlz2_real_sbx = get_problems()
    final_front = nsga3.evolve(dtlz2_real_sbx, 92)
    _, dtlz2_real_sbx = get_problems()
    final_front = dtlz2_real_sbx.evaluate(final_front)
    fitness = [list(p.fitness_metric) for p in final_front]
    phenotypes = [list(p.phenotype) for p in final_front]
    analytics["DTLZ2-NSGA3"]["evaluations"] = fitness
    analytics["DTLZ2-NSGA3"]["phenotypes"] = phenotypes

    # Dump analytics in a json in order to extract insights from it offline
    save_json('analytics', analytics)
    run+=1

