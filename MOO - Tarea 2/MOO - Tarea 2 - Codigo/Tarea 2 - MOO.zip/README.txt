Para instalar todas las dependencias necesarias para correr el proyecto
pip install -r requirements.txt

El folder: GA, contiene la implementación de NSGAII y III.
Las pruebas se pueden efectuar corriendo el archivo /GA/FunctionOptimizationTests.py de la siguiente manera:
python FunctionOptimizationTests.py

El folder: GD, contiene la implementación del gradiente descendiente.
Las pruebas se pueden efectuar corriendo el archivo /GD/descenso.py de la siguiente manera:
python descenso.py


La carpeta raíz contiene el reporte y los resultados en forma de un jupyter notebook llamado Analysis.ipynb